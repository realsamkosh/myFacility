﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telemed.Utilities.VideoUtility.Zoom.model.Key
{
    public class OAuth
    {
        public string ClientID { get; set; }
        public string RedirectURI { get; set; }
    }
}
