﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telemed.Utilities.VideoUtility.Zoom.model.Key
{
    public class ZoomAPIKey
    {
        public string APIKey { get; set; }
        public string APISecret { get; set; }
    }
}
