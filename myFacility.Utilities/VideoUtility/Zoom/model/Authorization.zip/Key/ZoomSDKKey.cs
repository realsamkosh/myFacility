﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telemed.Utilities.VideoUtility.Zoom.model
{
    public class ZoomSDKKey
    {
        public string SDKKey { get; set; }
        public string SDKSecret { get; set; }
    }
}
