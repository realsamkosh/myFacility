﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telemed.Utilities.VideoUtility.Zoom.model.Meeting
{
    public class GlobalDialInNumbers
    {
        public string city { get; set; }
        public string country { get; set; }
        public string country_name { get; set; }
        public string numbers { get; set; }
        public string type { get; set; }
    }
}
