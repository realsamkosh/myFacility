﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telemed.Utilities.VideoUtility.Zoom.model.Meeting
{
    public class GlobalDialInCountries
    {
        public string countrycode { get; set; }
    }
}
