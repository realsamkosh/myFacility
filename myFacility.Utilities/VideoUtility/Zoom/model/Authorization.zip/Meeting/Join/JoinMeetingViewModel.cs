﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telemed.Utilities.VideoUtility.Zoom.model.Meeting.Join
{
    public class JoinMeetingViewModel
    {
        public string signature { get; set; }
        public string username { get; set; }
        public string email { get; set; }
    }
}
